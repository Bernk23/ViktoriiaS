package Task2;

import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        abcpS();

        dehmin();

        random();

        decbin();

    }

    public static void abcpS() {
        double a = 3.0;
        double b = 2.0;
        double c = 4.0;
        double p = (a + b + c) / 2.0;
        double S = Math.sqrt(p * (p - a) * (p - b) * (p - c));
        System.out.println(S);
    }


    public static void dehmin() {

        double d = Math.random();
        double e = Math.random();
        double h = Math.random();
        double min = (Math.abs(d) < Math.abs(e) && Math.abs(d) < Math.abs(h)) ? d : (Math.abs(e) < Math.abs(d) && Math.abs(e) < Math.abs(h)) ? e : h;
        System.out.println(min);

    }

    public static void random() {
        Random g = new Random();
        int g1 = g.nextInt();
        int g2 = g1 % 2;
        if (g2 == 0) {
            System.out.println("Четное");
        } else {
            System.out.println("Нечетное");
        }
    }


    public static void decbin() {
        System.out.println("Введите Число");
        Scanner scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        int bin;
        String str = "";
        while (num > 0) {
            bin = num % 2;
            num /= 2;
            str += bin;
        }
        StringBuilder rev = new StringBuilder(str);
        rev.reverse();
        System.out.println(rev);
    }
}

