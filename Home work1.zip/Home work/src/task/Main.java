package task;

public class Main {
    public static void main(String[] args) {
        String name = "Svyrydova";
        String name2 = "Viktoriia";
        System.out.println(name + " " + name2);
        int v = name2.length();
        if (v > 7) {
            System.out.println("more than 7");
        } else if
        (v < 7) {
            System.out.println("less than 7");
        }
        int b = 0;
        for (int a = 5; a < 26; a = a + 2) {
            System.out.println("Шаг " + b + "," + " значение " + a);
            b++;
        }
    }
}
